

let datos = ['perro', 'gato', 'pajaro'];

console.log("Array original:");
for (let i = 0; i < datos.length; i++) {
  console.log(datos[i]);
}

// Insertar un elemento al final del array
datos.push('pez');

console.log("Array actualizado:");
for (let i = 0; i < datos.length; i++) {
  console.log(datos[i]);
}


