
var pedido = "carne";

switch (pedido) {
  case "carne":
    console.log("El cliente pidió carne. Se le ofrece vino tinto.");
    break;
  case "pescado":
    console.log("El cliente pidió pescado. Se le ofrece vino blanco.");
    break;
  case "verdura":
    console.log("El cliente pidió verdura. Se le ofrece agua.");
    break;
  default:
    console.log("Por favor, elija carne, pescado o verdura.");
    break;
}


