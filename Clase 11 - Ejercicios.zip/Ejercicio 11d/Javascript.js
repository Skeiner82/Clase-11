
let numero = 10;

while (numero < 11) {
  console.log("El número es más chico que 11");
  numero++;
}


