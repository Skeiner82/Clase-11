
let helado=2; 
let topping = "KitKat";
let precio;
let precioFinal;


if (helado === 1) {
  precio = 150;
} else if (helado === 2) {
  precio = 175; 
} else if (helado === 3) {
  precio =180; 
} else {
  precio = 0; 
}


if (topping === "Oreo") {
  precio += 10;
} else if (topping === "KitKat") {
  precio += 15;
} else if (topping === "Kinder") {
  precio += 25;
} else {
  console.log("No tenemos este topping");
}


precioFinal = precio;

console.log("El helado cuesta $" + precioFinal);
